dependencies: \
  /Users/mike/go/src/github.com/keybase/client/osx/Fuse/macfuse/Support/FileSystemBundle/Mounter/getmntopts.c \
  /Users/mike/go/src/github.com/keybase/client/osx/Fuse/macfuse/Support/FileSystemBundle/Mounter/mntopts.h
