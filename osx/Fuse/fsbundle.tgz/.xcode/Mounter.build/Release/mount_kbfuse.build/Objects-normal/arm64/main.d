dependencies: \
  /Users/mike/go/src/github.com/keybase/client/osx/Fuse/macfuse/Support/FileSystemBundle/Mounter/main.m \
  /Users/mike/go/src/github.com/keybase/client/osx/Fuse/macfuse/include/fuse_ioctl.h \
  /Users/mike/go/src/github.com/keybase/client/osx/Fuse/macfuse/include/fuse_mount.h \
  /Users/mike/go/src/github.com/keybase/client/osx/Fuse/macfuse/include/fuse_variant.h \
  /Users/mike/go/src/github.com/keybase/client/osx/Fuse/macfuse/include/fuse_param.h \
  /Users/mike/go/src/github.com/keybase/client/osx/Fuse/macfuse/include/fuse_version.h \
  /Users/mike/go/src/github.com/keybase/client/osx/Fuse/macfuse/Support/FileSystemBundle/Mounter/mntopts.h
