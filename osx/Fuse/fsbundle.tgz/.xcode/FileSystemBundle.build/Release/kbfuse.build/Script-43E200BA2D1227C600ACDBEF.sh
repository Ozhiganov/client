#!/bin/sh
/bin/rm -f "${BUILT_PRODUCTS_DIR}"/load_*
/bin/rm -f "${BUILT_PRODUCTS_DIR}"/mount_*

