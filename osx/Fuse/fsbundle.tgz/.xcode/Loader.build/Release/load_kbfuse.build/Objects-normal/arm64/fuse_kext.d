dependencies: \
  /Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/Darwin.modulemap \
  /Users/mike/go/src/github.com/keybase/client/osx/Fuse/macfuse/Support/FileSystemBundle/Loader/fuse_kext.m \
  /Users/mike/go/src/github.com/keybase/client/osx/Fuse/macfuse/Support/FileSystemBundle/Loader/fuse_kext.h \
  /Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/17/include/module.modulemap \
  /Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/DarwinFoundation1.modulemap \
  /Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/DarwinFoundation2.modulemap \
  /Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/DarwinFoundation3.modulemap \
  /Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/System/Library/Frameworks/CoreFoundation.framework/Modules/module.modulemap \
  /Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/System/Library/Frameworks/IOKit.framework/Modules/module.modulemap \
  /Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/libkern.modulemap \
  /Users/mike/go/src/github.com/keybase/client/osx/Fuse/macfuse/include/fuse_param.h \
  /Users/mike/go/src/github.com/keybase/client/osx/Fuse/macfuse/include/fuse_variant.h \
  /Users/mike/go/src/github.com/keybase/client/osx/Fuse/macfuse/include/fuse_version.h
